# SSHPLUS

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/Bigu2208/SSHPLUS/master/Plus && chmod 777 Plus && ./Plus


#Acessa Root

wget https://raw.githubusercontent.com/Bigu2208/SSHPLUS/master/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh
